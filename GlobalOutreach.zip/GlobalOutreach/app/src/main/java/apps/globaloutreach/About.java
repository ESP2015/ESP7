package apps.globaloutreach;

/**
 * Created by ptaylor on 6/22/15.
 */
import android.app.Activity;
import android.os.Bundle;

public class About extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);

    }
}
